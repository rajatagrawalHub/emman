import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useAuth } from '../context/AuthContext';
import '../App.css';

const UserDashboard = () => {
  const { logout } = useAuth();

  const [filters, setFilters] = useState({
    status: '',
    title: '',
    venue: '',
    mode: '',
    category: '',
    approvalStatus: 'Approved',
    certificate: '',
  });

  const [events, setEvents] = useState([]);
  const [error, setError] = useState('');

  const fetchFilteredEvents = async () => {
    try {
      const filterBody = { ...filters };

      if (filterBody.certificate === 'true') {
        filterBody.certificate = true;
      } else if (filterBody.certificate === 'false') {
        filterBody.certificate = false;
      } else {
        delete filterBody.certificate;
      }

      const res = await axios.post('http://localhost:5000/event/filterby', filterBody);
      setEvents(res.data.events);
    } catch (err) {
      setError('Error fetching events');
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFilters((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  useEffect(() => {
    fetchFilteredEvents();
  }, []);

  return (
    <div className="dashboard-container">
      <h2>User Dashboard</h2>
      <button className="logout-btn" onClick={logout}>Logout</button>

      <h3>Filter Events</h3>
      <div className="filter-form">
        <input name="title" placeholder="Title" onChange={handleChange} />
        <input name="venue" placeholder="Venue" onChange={handleChange} />
        <input name="category" placeholder="Category" onChange={handleChange} />
        <select name="mode" onChange={handleChange}>
          <option value="">Mode</option>
          <option>Online</option>
          <option>Offline</option>
          <option>Hybrid</option>
        </select>
        <select name="status" onChange={handleChange}>
          <option value="">Status</option>
          <option>Upcoming</option>
          <option>Completed</option>
          <option>Freezed</option>
        </select>
        <select name="certificate" onChange={handleChange}>
          <option value="">Certificate</option>
          <option value="true">Yes</option>
          <option value="false">No</option>
        </select>
        <button onClick={fetchFilteredEvents}>Apply Filters</button>
      </div>

      {error && <p className="error">{error}</p>}

      <h3>Available Events</h3>
      <table>
        <thead>
          <tr>
            <th>Title</th>
            <th>Category</th>
            <th>Venue</th>
            <th>Mode</th>
            <th>Dates</th>
            <th>Certificate</th>
          </tr>
        </thead>
        <tbody>
          {events.length === 0 ? (
            <tr><td colSpan="6">No events found</td></tr>
          ) : (
            events.map((event) => (
              <tr key={event._id}>
                <td>{event.title}</td>
                <td>{event.category}</td>
                <td>{event.venue}</td>
                <td>{event.mode}</td>
                <td>
                  {new Date(event.startDate).toLocaleDateString()} - {new Date(event.endDate).toLocaleDateString()}
                </td>
                <td>{event.certificate ? 'Yes' : 'No'}</td>
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
};

export default UserDashboard;
